﻿module.exports = {
    parmsForGet: function (srcBkt, srcKey) {
        return {
            Bucket: srcBkt,
            Key: srcKey
        }
    },
    parmsForPut: function (dstBucket, dstKey, data) {
        return {
            Bucket: dstBucket,
            Key: dstKey,
            Body: data
        }
    }
}